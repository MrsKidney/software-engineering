
import fit.Fixture;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Anna
 */
public class SetUp extends Fixture {
    static Klient klient;
    public SetUp() {
        klient = new Klient();
    }
}
