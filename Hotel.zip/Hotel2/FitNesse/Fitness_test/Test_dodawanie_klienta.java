
import fit.ColumnFixture;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Anna
 */
public class Test_dodawanie_klienta extends ColumnFixture{
    String imie;
    String nazwisko;
    String adres;
    LocalDate odKiedy;
    LocalDate doKiedy;
    boolean stanRachunku= false;
    boolean stanRezewacji=false;
    boolean stanZakwaterowania=false;
    

public boolean dodaj_klienta(){
    Klient klient = new Klient();
    List<Klient> listaKlientow= new ArrayList<>();
    klient.imie = imie; 
    klient.nazwisko = nazwisko;
    klient.adres = adres;
    klient.odKiedy = odKiedy;
    klient.doKiedy = doKiedy;
    klient.stanRachunku = stanRachunku;
    klient.stanRezewacji = stanRezewacji;
    klient.stanZakwaterowania = stanZakwaterowania;
    
    int s1= listaKlientow.size();
        listaKlientow.add(klient);
        SetUp.klient.dodajKlientaDoBazy(klient, listaKlientow);
    int s2 = listaKlientow.size();
    return s1!=s2;
}
}